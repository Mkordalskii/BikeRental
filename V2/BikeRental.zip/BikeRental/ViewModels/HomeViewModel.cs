﻿namespace BikeRental.ViewModels
{
    public class HomeViewModel : WorkspaceViewModel
    {
        public HomeViewModel()
        {
            this.DisplayName = "Strona główna";
        }
    }
}
