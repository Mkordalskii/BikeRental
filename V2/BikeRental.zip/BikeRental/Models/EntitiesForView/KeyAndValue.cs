﻿namespace BikeRental.Models.EntitiesForView
{
    //klasa do obslugi ComboBoxow
    public class KeyAndValue
    {
        public int Key { get; set; }
        public string Value { get; set; }
    }
}
