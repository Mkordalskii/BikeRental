﻿namespace BikeRental.Models.EntitiesForView
{
    public class StojakiForAllView
    {
        public int StojakId { get; set; }
        public string NazwaStacji { get; set; }
        public int NumerMiejsca { get; set; }
        public string CzySprawny { get; set; }
    }
}
