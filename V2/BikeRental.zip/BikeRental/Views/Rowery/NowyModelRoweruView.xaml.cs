﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NowyModelRoweruView.xaml
    /// </summary>
    public partial class NowyModelRoweruView : JedenViewBase
    {
        public NowyModelRoweruView()
        {
            InitializeComponent();
        }
    }
}
