﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NowyRowerView.xaml
    /// </summary>
    public partial class NowyRowerView : JedenViewBase
    {
        public NowyRowerView()
        {
            InitializeComponent();
        }
    }
}
