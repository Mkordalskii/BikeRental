﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for RoweryView.xaml
    /// </summary>
    public partial class RoweryView : WszystkieViewBase
    {
        public RoweryView()
        {
            InitializeComponent();
        }
    }
}
