﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for ModeleRowerowView.xaml
    /// </summary>
    public partial class ModeleRowerowView : WszystkieViewBase
    {
        public ModeleRowerowView()
        {
            InitializeComponent();
        }
    }
}
