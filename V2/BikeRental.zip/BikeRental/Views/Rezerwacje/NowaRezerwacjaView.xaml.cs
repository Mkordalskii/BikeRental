﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NowaRezerwacjaView.xaml
    /// </summary>
    public partial class NowaRezerwacjaView : JedenViewBase
    {
        public NowaRezerwacjaView()
        {
            InitializeComponent();
        }
    }
}
