﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for RezerwacjeView.xaml
    /// </summary>
    public partial class RezerwacjeView : WszystkieViewBase
    {
        public RezerwacjeView()
        {
            InitializeComponent();
        }
    }
}
