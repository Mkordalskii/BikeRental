﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for StojakiView.xaml
    /// </summary>
    public partial class StojakiView : WszystkieViewBase
    {
        public StojakiView()
        {
            InitializeComponent();
        }
    }
}
