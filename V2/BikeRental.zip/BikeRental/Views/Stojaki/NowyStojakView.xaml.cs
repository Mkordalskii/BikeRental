﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NowyStojakView.xaml
    /// </summary>
    public partial class NowyStojakView : JedenViewBase
    {
        public NowyStojakView()
        {
            InitializeComponent();
        }
    }
}
