﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for AbonamentyView.xaml
    /// </summary>
    public partial class AbonamentyView : WszystkieViewBase
    {
        public AbonamentyView()
        {
            InitializeComponent();
        }
    }
}
