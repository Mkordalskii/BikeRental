﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NowyAbonamentView.xaml
    /// </summary>
    public partial class NowyAbonamentView : JedenViewBase
    {
        public NowyAbonamentView()
        {
            InitializeComponent();
        }
    }
}
