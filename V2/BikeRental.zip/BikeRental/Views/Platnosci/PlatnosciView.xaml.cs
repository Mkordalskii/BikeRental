﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for PlatnosciView.xaml
    /// </summary>
    public partial class PlatnosciView : WszystkieViewBase
    {
        public PlatnosciView()
        {
            InitializeComponent();
        }
    }
}
