﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NowaPlatnoscView.xaml
    /// </summary>
    public partial class NowaPlatnoscView : JedenViewBase
    {
        public NowaPlatnoscView()
        {
            InitializeComponent();
        }
    }
}
