﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for RezerwacjeView.xaml
    /// </summary>
    public partial class PlanyCenoweView : WszystkieViewBase
    {
        public PlanyCenoweView()
        {
            InitializeComponent();
        }
    }
}
