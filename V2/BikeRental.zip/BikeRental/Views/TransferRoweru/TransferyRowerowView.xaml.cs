﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for TransferyRowerowView.xaml
    /// </summary>
    public partial class TransferyRowerowView : WszystkieViewBase
    {
        public TransferyRowerowView()
        {
            InitializeComponent();
        }
    }
}
