﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NowyTransferRoweru.xaml
    /// </summary>
    public partial class NowyTransferRoweru : JedenViewBase
    {
        public NowyTransferRoweru()
        {
            InitializeComponent();
        }
    }
}
