﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NoweZgloszenieSerwisoweView.xaml
    /// </summary>
    public partial class NoweZgloszenieSerwisoweView : JedenViewBase
    {
        public NoweZgloszenieSerwisoweView()
        {
            InitializeComponent();
        }
    }
}
