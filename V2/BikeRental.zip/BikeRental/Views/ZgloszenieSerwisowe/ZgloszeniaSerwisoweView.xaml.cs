﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for ZgloszeniaSerwisoweView.xaml
    /// </summary>
    public partial class ZgloszeniaSerwisoweView : WszystkieViewBase
    {
        public ZgloszeniaSerwisoweView()
        {
            InitializeComponent();
        }
    }
}
