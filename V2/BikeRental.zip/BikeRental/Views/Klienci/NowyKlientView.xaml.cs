﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for Klient.xaml
    /// </summary>
    public partial class NowyKlientView : JedenViewBase
    {
        public NowyKlientView()
        {
            InitializeComponent();
        }
    }
}
