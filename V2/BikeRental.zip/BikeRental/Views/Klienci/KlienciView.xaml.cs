﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for KlienciView.xaml
    /// </summary>
    public partial class KlienciView : WszystkieViewBase
    {
        public KlienciView()
        {
            InitializeComponent();
        }
    }
}
