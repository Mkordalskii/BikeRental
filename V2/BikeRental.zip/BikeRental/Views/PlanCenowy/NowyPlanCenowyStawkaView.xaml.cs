﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NowyPlanCenowyStawkaView.xaml
    /// </summary>
    public partial class NowyPlanCenowyStawkaView : JedenViewBase
    {
        public NowyPlanCenowyStawkaView()
        {
            InitializeComponent();
        }
    }
}
