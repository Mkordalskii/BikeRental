﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for PlanCenowyStawka.xaml
    /// </summary>
    public partial class PlanCenowyStawkaView : WszystkieViewBase
    {
        public PlanCenowyStawkaView()
        {
            InitializeComponent();
        }
    }
}
