﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NowyPlanCenowyView.xaml
    /// </summary>
    public partial class NowyPlanCenowyView : JedenViewBase
    {
        public NowyPlanCenowyView()
        {
            InitializeComponent();
        }
    }
}
