﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for PlanCenowyView.xaml
    /// </summary>
    public partial class PlanCenowyView : WszystkieViewBase
    {
        public PlanCenowyView()
        {
            InitializeComponent();
        }
    }
}
