﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for StacjeView.xaml
    /// </summary>
    public partial class StacjeView : WszystkieViewBase
    {
        public StacjeView()
        {
            InitializeComponent();
        }
    }
}
