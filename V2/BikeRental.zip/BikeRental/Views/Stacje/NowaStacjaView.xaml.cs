﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NowaStacjaView.xaml
    /// </summary>
    public partial class NowaStacjaView : JedenViewBase
    {
        public NowaStacjaView()
        {
            InitializeComponent();
        }
    }
}
