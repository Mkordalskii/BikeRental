﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NoweWypozyczenieOplataView.xaml
    /// </summary>
    public partial class NoweWypozyczenieOplataView : JedenViewBase
    {
        public NoweWypozyczenieOplataView()
        {
            InitializeComponent();
        }
    }
}
