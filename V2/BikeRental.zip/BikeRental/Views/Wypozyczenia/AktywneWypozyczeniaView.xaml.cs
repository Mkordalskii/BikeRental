﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for AktywneWypozyczeniaView.xaml
    /// </summary>
    public partial class AktywneWypozyczeniaView : WszystkieViewBase
    {
        public AktywneWypozyczeniaView()
        {
            InitializeComponent();
        }
    }
}
