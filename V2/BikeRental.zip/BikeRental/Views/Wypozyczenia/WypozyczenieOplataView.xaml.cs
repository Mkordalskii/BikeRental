﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for WypozyczenieOplataView.xaml
    /// </summary>
    public partial class WypozyczenieOplataView : WszystkieViewBase
    {
        public WypozyczenieOplataView()
        {
            InitializeComponent();
        }
    }
}
