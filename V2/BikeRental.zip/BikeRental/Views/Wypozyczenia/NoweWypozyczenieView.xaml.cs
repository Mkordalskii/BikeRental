﻿namespace BikeRental.Views
{
    /// <summary>
    /// Interaction logic for NoweWypozyczenieView.xaml
    /// </summary>
    public partial class NoweWypozyczenieView : JedenViewBase
    {
        public NoweWypozyczenieView()
        {
            InitializeComponent();
        }
    }
}
